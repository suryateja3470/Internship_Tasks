
# Problem: Tuples
# HackerRank: https://www.hackerrank.com/challenges/python-tuples/problem

n = int(raw_input())
integer_list = tuple(map(int, raw_input().split()))
print hash(integer_list)
